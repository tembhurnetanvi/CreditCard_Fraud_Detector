Subject: Data Science Methods and Tools Assignment 9
Author: Tanvi Tembhurne
Team Member: Swin Almeida
Team Member: Kanika Negi
Group: Phoenix 

Requirements:
Final Project

Submission: 
	This folder contains a pythonFile named TeamPheonixFinal.
	Credit Card csv file named creditcard.
	Final Prsentation named TeamPhoenix.
	Images folder containing images used in python file.


